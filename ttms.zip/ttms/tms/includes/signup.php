<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Form</title>

	<style>
    input[type="text"], input[type="email"], input[type="password"] {
        /* color: #000;
        background-color: #f9f9f9; */
        border: 1px solid #ccc;
        border-radius: 4px;
        padding: 10px;
        width: 100%;
        font-size: 14px;
        margin-bottom: 10px;
    }

    input[type="text"]:focus, input[type="email"]:focus, input[type="password"]:focus {
        border-color: #007bff;
        /* box-shadow: 0 0 4px rgba(0, 123, 255, 0.5); */
        outline: none;
    }

    .error-message {
        color: red;
        font-size: 12px;
        margin-top: -10px;
        margin-bottom: 10px;
        display: block;
    }
</style>
</head>
<body>
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <section>
                    <div class="modal-body modal-spa">
                        <div class="login-grids">
                            <div class="login">
                                <div class="login-right">
                                    <form name="signup" method="post">
                                        <h3>Create your account</h3>
                                        <input type="text" name="fname" placeholder="Full Name" autocomplete="off" required>
                                        <span id="fname-error" class="error-message"></span>

                                        <input type="text" name="mobilenumber" placeholder="Mobile Number" maxlength="10" autocomplete="off" required>
                                        <span id="mnumber-error" class="error-message"></span>

                                        <input type="email" name="email" placeholder="Email" id="email" autocomplete="off" required>
                                        <span id="email-error" class="error-message"></span>

                                        <input type="password" name="password" placeholder="Password" required>
                                        <span id="password-error" class="error-message"></span>

                                        <div class="modal-footer text-right">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                            <button type="submit" name="submit" id="submit" class="btn btn-primary">Create</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>

    <script>
        // JavaScript Validation for Signup Form
        function validateSignupForm() {
            let isValid = true;

            const fname = document.forms["signup"]["fname"].value.trim();
            const mnumber = document.forms["signup"]["mobilenumber"].value.trim();
            const email = document.forms["signup"]["email"].value.trim();
            const password = document.forms["signup"]["password"].value.trim();

            const fnameError = document.getElementById("fname-error");
            const mnumberError = document.getElementById("mnumber-error");
            const emailError = document.getElementById("email-error");
            const passwordError = document.getElementById("password-error");

            // Clear previous error messages
            fnameError.textContent = "";
            mnumberError.textContent = "";
            emailError.textContent = "";
            passwordError.textContent = "";

            // Full Name Validation
            if (fname === "") {
                fnameError.textContent = "Full Name cannot be empty.";
                isValid = false;
            } else if (!/^[a-zA-Z\s]+$/.test(fname)) {
                fnameError.textContent = "Full Name can only contain letters and spaces.";
                isValid = false;
            }

            // Mobile Number Validation
            if (mnumber === "") {
                mnumberError.textContent = "Mobile number cannot be empty.";
                isValid = false;
            } else if (!/^[0-9]{10}$/.test(mnumber)) {
                mnumberError.textContent = "Mobile number must be a 10-digit numeric value.";
                isValid = false;
            }

            // Email Validation
            if (email === "") {
                emailError.textContent = "Email cannot be empty.";
                isValid = false;
            } else {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(email)) {
                    emailError.textContent = "Please enter a valid email address.";
                    isValid = false;
                }
            }

            // Password Validation
            if (password === "") {
                passwordError.textContent = "Password cannot be empty.";
                isValid = false;
            } else if (password.length < 8) {
                passwordError.textContent = "Password must be at least 8 characters long.";
                isValid = false;
            } else {
                const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
                if (!passwordRegex.test(password)) {
                    passwordError.textContent = "Password must contain at least one uppercase letter, one lowercase letter, one digit, and one special character.";
                    isValid = false;
                }
            }

            return isValid;
        }

        // Attach validation to the form submission
        const signupForm = document.querySelector("form[name='signup']");
        signupForm.addEventListener("submit", function (event) {
            if (!validateSignupForm()) {
                event.preventDefault(); // Prevent form submission if validation fails
            }
        });
    </script>
</body>
</html>

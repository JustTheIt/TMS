<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>
<!doctype html>
<html lang="en-gb" class="no-js">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

  <title>My Travel - my memory</title>
  <meta name="description" content="Traveller">
  <meta name="author" content="WebThemez">

  <link rel="stylesheet" href="css/bootstrap.min.css" />
  <link rel="stylesheet" type="text/css" href="css/isotope.css" media="screen" />
  <link rel="stylesheet" href="js/fancybox/jquery.fancybox.css" type="text/css" media="screen" />
  <link rel="stylesheet" type="text/css" href="css/da-slider.css" />
  <link href="js/owl-carousel/owl.carousel.css" rel="stylesheet">
  <link rel="stylesheet" href="css/styles.css" />
  <!-- Font Awesome -->
  <!--animate-->
  <link href="assets/css/animate.css" rel="stylesheet" type="text/css" media="all">
  <link href="font/css/font-awesome.min.css" rel="stylesheet">
</head>

<body>
 <?php include('includes/header.php'); ?>
 <!--/.header-->
 <section id="home" style="position: relative; text-align: center; background-color: white;">
  <!-- Header for the logo and navigation -->
  <div style="position: absolute; top: 10px; left: 20px; font-size: 24px; font-weight: bold; color: #73af00;">
    YATRA
  </div>
  <div style="position: absolute; top: 10px; right: 20px; font-size: 14px; color: #ffffff; background-color: #2b79bf; padding: 5px 10px; border-radius: 5px;">
    Toll Number: 01-4455098 | <a href="#" style="color: #ffffff; text-decoration: none;">Sign Up</a> | <a href="#" style="color: #ffffff; text-decoration: none;">Sign In</a>
  </div>

  <!-- Banner image with text overlay -->
  <div style="width: 100%; height: 500px; overflow: hidden; position: relative; background: #f9f9f9;">
    <img src="images/travel.png" alt="banner" style="width: 100%; height: 100%; object-fit: cover;">

    <!-- Tagline overlay -->
    <div style="position: absolute; top: 20%; left: 50%; transform: translate(-50%, -50%); text-align: center;">
      <h1 style="font-size: 3rem; font-weight: thin; color: #000;">Travel with Us</h1>
    </div>
  </div>
</section>
<section id="introText">
  <div class="container">
    <div class="text-center adeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">
      <h1>Experience Nepal's Breathtaking Landscapes and Vibrant Culture – Travel with Yatra Today!</h1>
    </div>
  </div>
</section>



<!--Package-->
<section id="packages" class="secPad">
  <div class="container">
    <div class="heading text-center">
      <!-- Heading -->
      <h2>Most Popular Packages</h2>
    </div>
    <div class="">
      <h3>Package List</h3>
      <?php $sql = "SELECT * from tbltourpackages order by rand() ";
      $query = $dbh->prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        { 
          ?>
          <div class="rom-btm">
            <div class="col-md-3 room-left wow fadeInLeft animated" data-wow-delay=".5s">
              <img src="admin/pacakgeimages/<?php echo htmlentities($result->PackageImage);?>" class="img-responsive" alt="">
            </div>
            <div class="col-md-6 room-midle wow fadeInUp animated" data-wow-delay=".5s">
              <h4>Package Name: <?php echo htmlentities($result->PackageName);?></h4>
              <h6>Package Type : <?php echo htmlentities($result->PackageType);?></h6>
              <p><b> Location :</b> <?php echo htmlentities($result->PackageLocation);?></p>
              <p><b>Features</b> <?php echo htmlentities($result->PackageFetures);?></p>
            </div>
            <div class="col-md-3 room-right wow fadeInRight animated" data-wow-delay=".5s">
              <h5>Nrs. <?php echo htmlentities($result->PackagePrice);?></h5>
              <a href="package_details.php?pkgid=<?php echo htmlentities($result->PackageId);?>" class="view">Details</a>
            </div>
            <div class="clearfix"></div>
          </div>
          <?php 
        }
      } ?>
    </div>
    <div class="clearfix"></div>   
  </div>
</section>

<!--About-->
<section id="aboutUs" class="secPad">
  <div class="container">

    <div class="heading text-center adeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">
      <!-- Heading -->
      <h2>About Us</h2>
      <p>Experience the Wonders of Travel in Nepal</p>
    </div>
    <div class="row adeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">
      <div class="col-md-4">
        <img src="images/Yatra.png" alt="" class="">
      </div>
      <div class="col-md-8">
        <p>Nepal is a land of majestic mountains, ancient temples, and rich cultural heritage that captivates every traveler. From the towering peaks of the Himalayas to the serene valleys and bustling streets of Kathmandu, Nepal offers an unparalleled blend of adventure and tranquility.

At Yatra Travel Agency, we are passionate about bringing you closer to the heart of this beautiful country. With years of expertise, we specialize in crafting personalized travel experiences that suit every traveler’s needs. Whether you’re seeking thrilling treks, cultural immersion, or peaceful getaways, our dedicated team ensures a seamless and memorable journey.

Let us guide you through Nepal’s breathtaking landscapes and vibrant traditions. With Yatra Travel Agency, your dream adventure awaits! </p> 
        
      </div>
    </div>
  </div>   
</section>
<!--Quote-->
<section id="quote" class="bg-parlex">
  <div class="parlex-back">
    <div class="container secPad text-center">
      <h2>"The World is a book, and those who do not travel read only a page."
      </h2><h3>-Saint Augustine</h3>
    </div>
    <!--/.container-->
  </div>
</section>



      <!-- signup -->
      <?php include('includes/signup.php');?>     
      <!-- //signu -->
      <!-- signin -->
      <?php include('includes/signin.php');?>     
      <!-- //signin -->
  
  <!--/.container-->
</section>
<?php include('includes/footer.php'); ?>

<a href="#top" class="topHome"><i class="fa fa-chevron-up fa-2x"></i></a>
<script src="js/modernizr-latest.js"></script>
<script src="js/jquery-1.8.2.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/jquery.isotope.min.js" type="text/javascript"></script>
<script src="js/fancybox/jquery.fancybox.pack.js" type="text/javascript"></script>
<script src="js/jquery.nav.js" type="text/javascript"></script>
<script src="js/jquery.cslider.js" type="text/javascript"></script>
<script src="contact/contact_me.js"></script>
<script src="js/custom.js" type="text/javascript"></script>
<script src="js/owl-carousel/owl.carousel.js"></script>
</body>
</html>
